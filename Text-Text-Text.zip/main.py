text = "hello"

print(text)